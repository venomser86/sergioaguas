<?php
    $title ="Sobre Mi | ";
    include "head.php";
    include "sidebar.php";  
?>

    <div class="right_col" role="main"> <!-- page content -->
        <div class="">
            <div class="page-title">
            <br>
                <div class="row">
            	    
                  
                </div>
            </div>
        </div>
    </div><!-- /page content -->

<?php include "footer.php" ?>
